# shipflex_application

add the json-simple-1.1.jar library (can be found in the library folder) to your project class path in order to fix the errors!
