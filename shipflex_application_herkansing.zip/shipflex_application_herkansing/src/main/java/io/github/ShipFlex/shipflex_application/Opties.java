
package main.java.io.github.ShipFlex.shipflex_application;

// Imports
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class Opties {
    private String naam;
    private Integer prijs;
    private Map<String, List<Opties>> essentieleOpties;
    private Map<String, List<Opties>> extraOpties;
    private Integer aantalKeerGekocht;
    private Korting korting;

    // Constructor with default values
    public Opties(String naam, Integer prijs) {
        this.naam = naam;
        this.prijs = prijs;
        this.essentieleOpties = new HashMap<String, List<Opties>>();
        this.extraOpties = new HashMap<String, List<Opties>>();
        this.korting = new GeenKorting();
    }

    // Getters & Setters
    public String getNaam() {
        return naam;
    }

    public void setNaam(String naam) {
        this.naam = naam;
    }

    public Integer getPrijs() {
        return prijs;
    }

    public void setPrijs(Integer prijs) {
        this.prijs = prijs;
    }

    public Map<String, List<Opties>> getEssentieleOpties() {
        return this.essentieleOpties;
    }

    public Map<String, List<Opties>> getExtraOpties() {
        return this.extraOpties;
    }

    public Korting getKorting() {
        return korting;
    }

    public void setKorting(Korting korting) {
        this.korting = korting;
    }

    // Methode voor het toevoegen van Essentiële Opties
    public void addEssentieleOpties(String categorie, String naam, Integer prijs) {
        Opties optie = new Opties(naam, prijs);

        if (!this.essentieleOpties.containsKey(categorie)) {
            this.essentieleOpties.put(categorie, new ArrayList<Opties>());
        }
        this.essentieleOpties.get(categorie).add(optie);
    }

    // Methode voor het toevoegen van Extra Opties
    public void addExtraOpties(String categorie, String naam, Integer prijs) {
        Opties optie = new Opties(naam, prijs);

        if (!this.extraOpties.containsKey(categorie)) {
            this.extraOpties.put(categorie, new ArrayList<Opties>());
        }
        this.extraOpties.get(categorie).add(optie);
    }
}
