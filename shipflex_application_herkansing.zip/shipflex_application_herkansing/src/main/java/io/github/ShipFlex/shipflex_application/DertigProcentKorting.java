package main.java.io.github.ShipFlex.shipflex_application;

public class DertigProcentKorting extends Korting {
    @Override
    public double berekenKorting(double prijs) {
        return prijs * 0.7;
    }

    public String getBeschrijving() {
        return "30% korting";
    }
}
