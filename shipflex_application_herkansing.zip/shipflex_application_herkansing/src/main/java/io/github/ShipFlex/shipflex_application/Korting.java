package main.java.io.github.ShipFlex.shipflex_application;

public abstract class Korting {

    public abstract double berekenKorting(double rate);
    public abstract String getBeschrijving();


}
