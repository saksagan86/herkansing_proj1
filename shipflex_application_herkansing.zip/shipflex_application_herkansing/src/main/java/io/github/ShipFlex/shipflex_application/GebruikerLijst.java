package main.java.io.github.ShipFlex.shipflex_application;

import java.util.ArrayList;
import java.util.List;

public class GebruikerLijst {
    private List<Gebruiker> gebruikers;

    public GebruikerLijst() {
        this.gebruikers = new ArrayList<>();
    }

    public List<Gebruiker> getGebruikers() {
        return gebruikers;
    }
    public void voegGebruikerToe(Gebruiker gebruiker) {
        this.gebruikers.add(gebruiker);
    }

}
