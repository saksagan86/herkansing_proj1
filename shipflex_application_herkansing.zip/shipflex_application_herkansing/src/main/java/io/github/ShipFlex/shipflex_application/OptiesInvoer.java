package main.java.io.github.ShipFlex.shipflex_application;

// Imports
import java.io.FileReader;
import java.io.IOException;
import java.util.*;
import java.io.File;

// JSON.Simple Imports
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class OptiesInvoer implements OptieValidatie {
    private List<Opties> geselecteerdeOpties = new ArrayList<Opties>();
    private Scanner input;
    private Opties opties;
    private static Map<String, Integer> optieTeller = new HashMap<>();

    private String filename = "opties.json";

    // Constructor
    public OptiesInvoer() {
        this.input = new Scanner(System.in);
    }
    public Map<String, Integer> getOptieTeller() {
        return optieTeller;
    }

    public Opties getOpties() {
        Opties opties = new Opties("Boot", 0);
        addEssentieleOpties(opties);
        addExtraOpties(opties);
        return opties;
    }

    public List<Opties> getGeselecteerdeOpties() {
        return geselecteerdeOpties;
    }

    @Override
    public void validatieKeuze() {
        System.err.println(
                "\n** Er is een fout opgetreden tijdens het lezen van het bestand. Wilt u doorgaan zonder de Extra Opties? (Ja/Nee) **");
        String antwoord = input.nextLine().toLowerCase();
        if (antwoord.equals("ja")) {
            return;
        } else if (antwoord.equals("nee")) {
            System.exit(0);
        } else {
            System.out.println("Ongeldige invoer. Het programma stopt nu.");
            System.exit(0);
        }
    }

    // Functie om de essentiële opties uit een JSON file (database) uit te lezen en
    // toe te voegen aan een object van het type Opties.
    public void addEssentieleOpties(Opties opties) {
        JSONParser parser = new JSONParser();
        try (FileReader reader = new FileReader(filename)) {
            JSONObject obj = (JSONObject) parser.parse(reader);
            JSONArray essentieleOpties = (JSONArray) obj.get("essentieleOpties");
            
            for (Object o : essentieleOpties) {
                JSONObject optie = (JSONObject) o;
                String categorie = (String) optie.get("categorie");
                String naam = (String) optie.get("naam");
                Number prijsObj = (Number) optie.get("prijs");
                Integer prijs = prijsObj.intValue();

                opties.addEssentieleOpties(categorie, naam, prijs);
                geselecteerdeOpties.add(opties);
            }

        } catch (IOException | ParseException e) {
            System.err.println(
                    "\nEr is een fout opgetreden tijdens het lezen van het bestand: " + e.getMessage());
            System.exit(0);
        }
    }

    // Functie om de extra opties uit een JSON file (database) uit te lezen en toe
    // te voegen aan een object van het type Opties.
    public void addExtraOpties(Opties opties) {
        JSONParser parser = new JSONParser();
        try (FileReader reader = new FileReader(filename)) {
            JSONObject obj = (JSONObject) parser.parse(reader);
            JSONArray extraOpties = (JSONArray) obj.get("extraOpties");
            
            for (Object o : extraOpties) {
                JSONObject optie = (JSONObject) o;
                String categorie = (String) optie.get("categorie");
                String naam = (String) optie.get("naam");
                Number prijsObj = (Number) optie.get("prijs");
                Integer prijs = prijsObj.intValue();
               
                opties.addExtraOpties(categorie, naam, prijs);
                geselecteerdeOpties.add(opties);

            }

        } catch (IOException | ParseException e) {
            validatieKeuze();
        }
    }

    // Funtie om de essentiële opties weer te geven aan de gebruiker, de functie
    // roept daarna ook de *displayExtraOpties* functie op
    // die de extra opties print.
    public void displayEssentieleOpties(Opties opties) {
        System.out.println("=====================================");
        System.out.println("--- ESSENTIËLE OPTIES ---");
        Map<String, List<Opties>> essentieleOpties = opties.getEssentieleOpties();
        for (String categorie : essentieleOpties.keySet()) {
            System.out.println("\n|" + categorie + "|");
            
            for (Opties optie : essentieleOpties.get(categorie)) {
                System.out.println("  - " + optie.getNaam() + " (" + optie.getPrijs() + " EUR)");
            }
        }
        displayExtraOpties(opties);
    }

    public void displayExtraOpties(Opties opties) {
        System.out.println("\n--- EXTRA OPTIES ---");

        Map<String, List<Opties>> extraOpties = opties.getExtraOpties();
        for (String categorie : extraOpties.keySet()) {
            System.out.println("\n|" + categorie.toUpperCase() + "|");
            
            for (Opties optie : extraOpties.get(categorie)) {
                System.out.println("  - " + optie.getNaam() + " (" + optie.getPrijs() + " EUR)");
            }
        }
        System.out.println("=====================================");
    }

    // Functie om de gebruiker zowel essentiële als extra opties te laten
    // selecteren, het neemt een Opties object in en returned een List van Opties
    // objecten.
    // Hierbij leest hij de JSON file uit en filtert alle categorieën en print deze
    // vervolgens.
    // Er wordt ook rekening gehouden met categorieën die al zijn verwerkt.
    public List<Opties> optiesJSON(Opties opties) {
        List<Opties> geselecteerdeOpties = new ArrayList<Opties>();
        Set<String> behandeldeCategorieen = new HashSet<String>();
        JSONParser parser = new JSONParser();
        
        try (FileReader reader = new FileReader(filename)) {
            JSONObject obj = (JSONObject) parser.parse(reader);
            JSONArray essentieleOpties = (JSONArray) obj.get("essentieleOpties");
            JSONArray extraOpties = (JSONArray) obj.get("extraOpties");
            selecteerOpties(opties, geselecteerdeOpties, behandeldeCategorieen, essentieleOpties);
            selecteerExtraOpties(opties, geselecteerdeOpties, behandeldeCategorieen, extraOpties);

        } catch (IOException | ParseException e) {
            System.err.println(
                    "\nEr is een fout opgetreden tijdens het lezen van het bestand: " + e.getMessage());
            System.exit(0);
        }
        return geselecteerdeOpties;
    }

    // Functie die itereert over een JSON array bestaande uit essentiele opties en
    // vraagt de gebruiker om een
    // optie te selecteren uit elke categorie die nog niet geselecteerd is.
    private void selecteerOpties(Opties opties, List<Opties> geselecteerdeOpties, Set<String> behandeldeCategorieen,
            JSONArray essentieleOpties) {
        for (Object o : essentieleOpties) {
            JSONObject optie = (JSONObject) o;
            String categorie = (String) optie.get("categorie");
            
            if (!behandeldeCategorieen.contains(categorie)) {
                while (true) {
                    Opties gekozenOptie = kiesOptie(
                            "\nSelecteer een optie uit de categorie '" + categorie.toUpperCase() + "'",
                            opties.getEssentieleOpties());

                    //
                    boolean gekozenMaaktDeelVanCategorie = false;
                    for (Object x : essentieleOpties) {
                        JSONObject y = (JSONObject) x;

                        String yCat = (String) y.get("categorie");
                        String yNaam = (String) y.get("naam");

                        if (yCat.equals(categorie)
                                && gekozenOptie.getNaam().toLowerCase().equals(yNaam.toLowerCase())) {
                            gekozenMaaktDeelVanCategorie = true;
                            break;
                        }
                    }

                    if (gekozenMaaktDeelVanCategorie) {
                        geselecteerdeOpties.add(gekozenOptie);

                        behandeldeCategorieen.add(categorie);

                        break;
                    } else {
                        System.out.printf("Keuze '%s' maakt geen deel van de categorie '%s'.", gekozenOptie.getNaam().toUpperCase(),
                                categorie.toUpperCase());
                    }
                }
            }
        }
    }

    // Functie die de gebruiker vraagt of er nog extra opties gekozen moeten worden,
    // herhaalt vervolgens een JSON-array
    // met extra opties en vraagt de gebruiker vervolgeens om een optie te
    // selecteren uit elke categorie die nog niet
    // geselecteerd is.
    private void selecteerExtraOpties(Opties opties, List<Opties> geselecteerdeOpties,
            Set<String> behandeldeCategorieen,
            JSONArray extraOpties) {
        System.out.println("\nWilt u extra opties kiezen? (Ja/Nee)");
        String keuze = input.nextLine().toLowerCase();
        
        if (keuze.equals("ja")) {
            for (Object o : extraOpties) {
                JSONObject optie = (JSONObject) o;
                String categorie = (String) optie.get("categorie");
                selecteerMeerOpties(opties, geselecteerdeOpties, behandeldeCategorieen, categorie);
            }
        }
    }

    // Functie die de gebruiker vraagt om extra opties uit een specifieke categorie
    // te selecteren
    // totdat de gebruiker van de applicatie ervoor kiest om te stoppen.
    private void selecteerMeerOpties(Opties opties, List<Opties> geselecteerdeOpties, Set<String> behandeldeCategorieen,
            String categorie) {
        if (!behandeldeCategorieen.contains(categorie) && vraagExtraOpties(categorie)) {
            boolean meerOpties = true;
            
            while (meerOpties) {
                Opties geselecteerdeOptie = kiesOptie(
                        "\nSelecteer een optie uit de categorie '" + categorie.toUpperCase() + "'",
                        opties.getExtraOpties());
                geselecteerdeOpties.add(geselecteerdeOptie);

                meerOpties = vraagMeerOpties(categorie);
            }
        }
        behandeldeCategorieen.add(categorie);
    }

    // Functie die vraagt of de gebruiker extra opties uit een specifieke categorie
    // willen selecteren.
    private boolean vraagExtraOpties(String categorie) {
        System.out.println("\nWilt u opties uit de categorie '" + categorie.toUpperCase() + "' kiezen? (Ja/Nee)");
        while (true) {
            String extraOptiesAntwoord = input.nextLine().toLowerCase();
            
            if (extraOptiesAntwoord.equals("ja")) {
                return true;
            } else if (extraOptiesAntwoord.equals("nee")) {
                return false;
            } else {
                System.out.println("Ongeldige invoer. Voer alstublieft 'JA' of 'NEE' in.");
            }
        }
    }

    // Functie die vraagt of de gebruiker meer extra opties uit een specifieke
    // categorie willen selecteren.
    private boolean vraagMeerOpties(String categorie) {
        System.out.println(
                "\nWilt u meer opties uit deze categorie (" + categorie.toUpperCase() + ") kiezen? (Ja/Nee)");
        while (true) {
            String meerOptiesAntwoord = input.nextLine().toLowerCase();
            
            if (meerOptiesAntwoord.equals("ja")) {
                return true;
            } else if (meerOptiesAntwoord.equals("nee")) {
                return false;
            } else {
                System.out.println("Ongeldig invoer. Voer alstublieft 'JA' of 'NEE' in.");
            }
        }
    }

    // Vraagt de gebruiker om een optie te selecteren uit een lijst met optiest en
    // retourneert de geselecteerde optie(s)
    public Opties kiesOptie(String prompt, Map<String, List<Opties>> optiesCategorie) {
        Scanner s = new Scanner(System.in);
        Opties gekozenOptie = null;

        while (gekozenOptie == null) {
            System.out.println(prompt);
            String input = s.nextLine();

            gekozenOptie = zoekOptie(input, optiesCategorie);
            if (gekozenOptie != null) {
                if (!geselecteerdeOpties.contains(gekozenOptie)) {
                    geselecteerdeOpties.add(gekozenOptie);
                    updateOptieTeller(gekozenOptie.getNaam(), getOpties());
                    if (isExtraOptie(gekozenOptie.getNaam(), getOpties())) {
                        kenPersoonlijkeKortingToe(gekozenOptie);
                        VoegKortingToe(gekozenOptie);
                    }
                } else {
                    System.out.println("Deze optie is al gekozen. Kies een andere optie.");
                    gekozenOptie = null;
                }
            } else {
                System.out.println("Ongeldige optie. Kies een andere optie.");
            }
        }
        return gekozenOptie;
    }

    // Zoekt in een lijst met opies naar een opties met een overeenkomende naam en
    // retourneert dit.
    private Opties zoekOptie(String input, Map<String, List<Opties>> opties) {
        for (List<Opties> optieList : opties.values()) {
            for (Opties optie : optieList) {
                if (optie.getNaam().equalsIgnoreCase(input)) {
                    return optie;
                }
            }
        }
        return null;
    }

    // Methode vraagt of een bepaalde optie in aanmerking komt voor korting en zo
    // ja, kan de gebruiker handmatig
    // het kortinspercentage in voeren. Vervolgens wordt de methode berekenKorting
    // gecalled.
    public void VoegKortingToe(Opties optie) {
        Scanner s =new Scanner(System.in);
        String antwoord = "";
        boolean validAntwoord = false;
        while (!validAntwoord) {
            System.out.println("Komt deze optie in aanmerking voor een milieu korting? (Ja/Nee)");
            antwoord = s.nextLine();

            if (antwoord.equalsIgnoreCase("ja") || antwoord.equalsIgnoreCase("nee")) {
                validAntwoord = true;
            } else {
                System.out.println("Ongeldige keuze, kies Ja of Nee!");
            }
        }

        if (antwoord.equalsIgnoreCase("ja")) {
            Integer korting = 0;
            boolean validKorting = false;
            while (!validKorting) {
                System.out.print("Aantal procent korting voor deze optie is:  ");
                String kortingInput = s.nextLine();

                validKorting = berekenKorting(optie, validKorting, kortingInput);
            }
        } else {
            // Apply only personal discount when "nee" is chosen
            double persoonlijkeKorting = optie.getKorting().berekenKorting(optie.getPrijs());
            int eindprijs = (int) (optie.getPrijs() - persoonlijkeKorting);
            optie.setPrijs(eindprijs);
            System.out.println("Persoonlijke korting van " + optie.getKorting().getBeschrijving() + " toegepast op " + optie.getNaam());
            System.out.println("De nieuwe prijs van " + optie.getNaam().toUpperCase() + " is " + optie.getPrijs());
        }
    }



    public boolean berekenKorting(Opties optie, boolean validKorting, String kortingInvoer) {
        int korting;
        try {
            korting = Integer.parseInt(kortingInvoer);
            if (korting >= 0 && korting <= 100) {
                double milieukorting = (100 - korting) / 100.0;
                double afgeprijsdBedrag = optie.getPrijs() * milieukorting;
                double persoonlijkeKorting = optie.getKorting().berekenKorting(afgeprijsdBedrag);
                int eindprijs = (int) (afgeprijsdBedrag - persoonlijkeKorting);
                optie.setPrijs(eindprijs);
                System.out.println("Persoonlijke korting van " + optie.getKorting().getBeschrijving() + " en milieukorting van " + korting + "% toegepast op " + optie.getNaam());
                System.out.println("De nieuwe prijs van " + optie.getNaam().toUpperCase() + " is " + optie.getPrijs());
                validKorting = true;
            } else {
                System.out.println("Ongeldig kortingspercentage. Voer een waarde tussen 0 en 100 in.");
            }
        } catch (NumberFormatException e) {
            System.out.println("Ongeldige kortingspercentage. Gelieve een numerieke waarde in te vullen");
        }
        return validKorting;
    }

    private boolean isExtraOptie(String optieNaam, Opties opties) {
        Map<String, List<Opties>> extraOpties = opties.getExtraOpties();
        for (List<Opties> optieList : extraOpties.values()) {
            for (Opties optie : optieList) {
                if (optie.getNaam().equalsIgnoreCase(optieNaam)) {
                    return true;
                }
            }
        }
        return false;
    }
    public void updateOptieTeller(String optieNaam, Opties opties) {
        if (isExtraOptie(optieNaam, opties)) {
            optieTeller.put(optieNaam, optieTeller.getOrDefault(optieNaam, 0) + 1);
        }
    }

    public void resetOptieTeller() {
        optieTeller.clear();
    }
    public void kenPersoonlijkeKortingToe(Opties optie) {
        if (isExtraOptie(optie.getNaam(), getOpties())) {
            int gekozenAantal = optieTeller.getOrDefault(optie.getNaam(), 0);

            if (gekozenAantal == 2) {
                optie.setKorting(new DertigProcentKorting()); // 30% korting
            } else if (gekozenAantal >= 4) { // Vaak gekocht
                optie.setKorting(new DrieVoorDePrijsVanTweeKorting()); // 3 voor de prijs van 2
            } else if (gekozenAantal == 3) {
                optie.setKorting(new TweeVoorDePrijsVanEenKorting()); // 2 voor de prijs van 1
            } else {
                optie.setKorting(new VijftigProcentKorting()); // 50% korting
            }
        }
    }

}
