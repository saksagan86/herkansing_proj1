package main.java.io.github.ShipFlex.shipflex_application;

public class DrieVoorDePrijsVanTweeKorting extends Korting {
    @Override
    public double berekenKorting(double prijs) {
        return (2 * prijs) / 3;
    }

    public String getBeschrijving() {
        return "3 voor de prijs van 2 ";
    }
}