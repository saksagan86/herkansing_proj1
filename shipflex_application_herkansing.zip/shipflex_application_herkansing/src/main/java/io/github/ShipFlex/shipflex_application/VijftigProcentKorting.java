package main.java.io.github.ShipFlex.shipflex_application;

public class VijftigProcentKorting extends Korting {

    @Override
    public double berekenKorting(double prijs) {
        return prijs * 0.5;
    }
    public String getBeschrijving() {
        return "50% korting";
    }

}