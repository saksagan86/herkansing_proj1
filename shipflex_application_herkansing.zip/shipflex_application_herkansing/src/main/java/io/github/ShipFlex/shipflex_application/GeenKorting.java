package main.java.io.github.ShipFlex.shipflex_application;

public class GeenKorting extends Korting {
    @Override
    public double berekenKorting(double prijs) {
        return 0.0;
    }

    public String getBeschrijving() {
        return "geen";
    }
}
