// Package
package main.java.io.github.ShipFlex.shipflex_application;

// Imports
import java.io.IOException;
public class Main {
    public static void main(String args[]) throws IOException {
        BeginMenu beginMenu = new BeginMenu();
        beginMenu.start();

    }
}

