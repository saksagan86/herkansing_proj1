package main.java.io.github.ShipFlex.shipflex_application;

public interface OptieValidatie {
    public void validatieKeuze();
}
