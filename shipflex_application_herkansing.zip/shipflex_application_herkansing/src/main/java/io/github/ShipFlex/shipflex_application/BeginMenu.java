package main.java.io.github.ShipFlex.shipflex_application;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class BeginMenu {

    private Scanner invoer;
    private List<Gebruiker> gebruikers;
    private GebruikerLijst gebruikerLijst;
    private ArrayList<String> toonWikiMenu = new ArrayList<>();


    public BeginMenu() {
        this.invoer = new Scanner(System.in);
        this.gebruikers = new ArrayList<>();
        this.gebruikers.add(new Gebruiker("klant1","wachtwoord1"));
        this.gebruikers.add(new Gebruiker("klant2", "wachtwoord2"));
        this.gebruikerLijst = new GebruikerLijst();
        toonWikiMenu.add("Scheepstype");
        toonWikiMenu.add("Stuurinrichting");
        toonWikiMenu.add("Romp");
        toonWikiMenu.add("Motortype");
        toonWikiMenu.add("Stoelen");
        toonWikiMenu.add("Navigatie");
        toonWikiMenu.add("Comfort");
        toonWikiMenu.add("Veiligheid");
    }

    public void start() throws IOException {
        int menuOptie;
        OptiesInvoer oi = new OptiesInvoer();

        do {
            menuOptie = welkomsBericht();

            if (menuOptie == 1) {
                handleLogin(oi);
            } else if (menuOptie == 2) {
                registreerGebruiker();
            }
        } while (menuOptie != 3);
    }

    public void handleLogin(OptiesInvoer oi) throws IOException {
        System.out.println("Voer uw gebruikersnaam en wachtwoord in om in te loggen:");
        System.out.print("Gebruikersnaam:   ");
        String gebruikersnaam = invoer.nextLine();
        System.out.print("Wachtwoord    :   ");
        String wachtwoord = invoer.nextLine();

        if (checkLogin(gebruikersnaam, wachtwoord)) {
            loggedInActions(oi);
        } else {
            System.out.println("Ongeldige gebruikersnaam of wachtwoord. Probeer opnieuw.");
        }
    }

    private void loggedInActions(OptiesInvoer oi) throws IOException {
        int keuze;
        do {
            keuze = toonHoofdmenu();

            if (keuze == 1) {
                toonKlanttyppes();
            }

            if (keuze == 2) {
                toonUitgebreideOptielijst();
            }

            if (keuze == 3) {
                genereerOfferte();
            }

        } while (keuze != 4);
        oi.resetOptieTeller();
    }
    public void registreerGebruiker() {
        System.out.println("====| Registratie |====");
        System.out.print("Voer een gebruikersnaam in:   ");
        String gebruikersnaam = invoer.nextLine();
        System.out.print("Voer een wachtwoord in    :   ");
        String wachtwoord = invoer.nextLine();

        Gebruiker nieuweGebruiker = new Gebruiker(gebruikersnaam, wachtwoord);
        gebruikerLijst.voegGebruikerToe(nieuweGebruiker);

        System.out.println("Registratie voltooid. U kunt nu inloggen met uw nieuwe account.");
    }
    public boolean checkLogin(String gebruikersnaam, String wachtwoord) {
        for (Gebruiker gebruiker : gebruikerLijst.getGebruikers()) {
            if (gebruiker.getGebruikersnaam().equals(gebruikersnaam) && gebruiker.getWachtwoord().equals(wachtwoord)) {
                return true;
            }
        }
        return false;
    }


    public int welkomsBericht() {
        int optie;
        while (true) {
            System.out.println("====| Welkom bij de OfferteGenerator van ShipFlex |====");
            System.out.println("\nSelecteer hieronder wat u wilt doen:");
            System.out.println(
                    "--------------\n1. Inloggen\n2. Registreren\n3. Afsluiten");

            String invoerString = invoer.nextLine();
            try {
                optie = Integer.parseInt(invoerString);

                if (optie < 1 || optie > 3) {
                    System.out.println("Ongeldige invoer, probeer opnieuw!");
                } else {
                    break;
                }

            } catch (NumberFormatException e) {
                System.out.println("Ongeldige invoer, probeer opnieuw!");
            }
        }
        return optie;
    }
    public int toonHoofdmenu() {
        int optie;
        while (true) {
            System.out.println("\nSelecteer hieronder wat u wilt doen:");
            System.out.println(
                    "--------------\n1. Klanttypes inzien\n2. Uitgebreide optielijst weergeven\n3. Offerte genereren\n4. Uitloggen");

            String invoerString = invoer.nextLine();
            try {
                optie = Integer.parseInt(invoerString);

                if (optie < 1 || optie > 4) {
                    System.out.println("Ongeldige invoer, probeer opnieuw!");
                } else {
                    break;
                }

            } catch (NumberFormatException e) {
                System.out.println("Ongeldige invoer, probeer opnieuw!");
            }
        }
        return optie;
    }

    private int valideerCategorieKeuze() {
        int gekozenCategorie = 0;
        boolean isGeldigeInvoer = false;
        while (!isGeldigeInvoer) {
            try {
                gekozenCategorie = Integer.parseInt(invoer.nextLine());
                if (gekozenCategorie < 1 || gekozenCategorie > 9) {
                    System.out.println("Ongeldige invoer, probeer opnieuw!");
                } else {
                    isGeldigeInvoer = true;
                }
            } catch (NumberFormatException e) {
                System.out.println("Ongeldige invoer, probeer opnieuw!");
            }
        }
        return gekozenCategorie;
    }

    private void toonUitgebreideOptielijst() {
        JSONObject jsonObject = leesJsonBestand("wiki.json");
        JSONArray essentieleOptiesArray = (JSONArray) jsonObject.get("wikiEssentieleOpties");
        JSONArray extraOptiesArray = (JSONArray) jsonObject.get("wikiExtraOpties");

        while (true) {
            int gekozenCategorie = toonCategorieMenu();

            if (gekozenCategorie == 9) {
                break;
            }

            if (gekozenCategorie >= 1 && gekozenCategorie <= 4) {
                System.out.println("\nEssentiele opties:\n");
                toonOptiesPerCategorie(essentieleOptiesArray, gekozenCategorie);
            } else {
                System.out.println("\nExtra opties:\n");
                toonOptiesPerCategorie(extraOptiesArray, gekozenCategorie);
            }

            int actie = toonActieMenu();

            if (actie == 1) {
                break;
            }
        }
    }

    private int toonCategorieMenu() {
        System.out.println("\nKies een categorie:\n--------------");
        for (int i = 0; i < toonWikiMenu.size(); i++) {
            System.out.printf("%d. %s%n", i+1, toonWikiMenu.get(i));
        }
        System.out.println(toonWikiMenu.size() + 1 + ". Terug naar hoofdmenu");

        return valideerCategorieKeuze();
    }

    private int toonActieMenu() {
        System.out.println();
        System.out.println("\nSelecteer wat u wilt doen:");
        System.out.println("1. Terug naar hoofdmenu");
        System.out.println("2. Opnieuw categorie kiezen om verder informatie te lezen");

        while (true) {
            String invoerString = invoer.nextLine();
            try {
                int optie = Integer.parseInt(invoerString);

                if (optie < 1 || optie > 2) {
                    System.out.println("Ongeldige invoer, probeer opnieuw!");
                } else {
                    return optie;
                }

            } catch (NumberFormatException e) {
                System.out.println("Ongeldige invoer, probeer opnieuw!");
            }
        }
    }

    private void printWrappedText(String text, int maxWidth) {
        String[] words = text.split(" ");
        String line = "";

        for (String word : words) {
            if (line.length() + word.length() + 1 > maxWidth) {
                System.out.println(line);
                line = "";
            }
            if (!line.isEmpty()) {
                line += " ";
            }
            line += word;
        }
        if (!line.isEmpty()) {
            System.out.println(line);
        }
    }

    private void toonOptiesPerCategorie(JSONArray optiesArray, int categorieIndex) {
        String[] categorieen = {"Scheepstype", "Romp", "Stuurinrichting", "Motortype", "Stoelen", "Navigatie", "Comfort", "Veiligheid"};
        String gekozenCategorieNaam = categorieen[categorieIndex - 1];

        for (int i = 0; i < optiesArray.size(); i++) {
            JSONObject optie = (JSONObject) optiesArray.get(i);
            if (optie.get("categorie").equals(gekozenCategorieNaam)) {
                String naam = (String) optie.get("naam");
                String info = (String) optie.get("info");
                double prijs = ((Number) optie.get("prijs")).doubleValue();

                System.out.println(naam + ": (Prijs: " + prijs + ")");
                printWrappedText("@" + info + "\n", 60);
            }
        }
    }

    private JSONObject leesJsonBestand(String filename) {
        JSONParser parser = new JSONParser();
        JSONObject jsonObject = null;
        try (FileReader reader = new FileReader(filename)) {
            jsonObject = (JSONObject) parser.parse(reader);
        } catch (IOException | ParseException e) {
            System.err.println("\nEr is een fout opgetreden tijdens het lezen van het bestand: " + e.getMessage());
            System.exit(0);
        }
        return jsonObject;
    }

    private void genereerOfferte() throws IOException {
        KlantInvoer klantInvoer = new KlantInvoer();
        Klant klant = klantInvoer.getKlantGegevens();

        OptiesInvoer oi = new OptiesInvoer();
        Opties op = oi.getOpties();

        oi.displayEssentieleOpties(op);
        oi.optiesJSON(op);

        System.out.println("");

        // vraagt de gebruiker of de offerte extern geschreven moet worden
        System.out.println("Wilt u de offerte opslaan in een tekstbestand? (Ja/Nee)");
        String invoerString = invoer.nextLine();
        boolean printToFile = invoerString.equalsIgnoreCase("ja");

        while ((!invoerString.equalsIgnoreCase("ja") ) && (!invoerString.equalsIgnoreCase("nee")))  {
            System.out.println("Ongeldige invoer, probeer opnieuw!");

            System.out.println("Wilt u de offerte opslaan in een tekstbestand? (Ja/Nee)");
         invoerString = invoer.nextLine();
         printToFile = invoerString.equalsIgnoreCase("ja");
             }

        if (printToFile) {
            System.out.println("Geef een bestandsnaam op voor de offerte:");
            String bestandsnaam = invoer.nextLine();
            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            LocalDateTime nu = LocalDateTime.now();
            String datum = dtf.format(nu);
            String folder = "offertes\\";
            String filename = folder + bestandsnaam + "-" + datum + ".txt";
            Offerte of = new Offerte(klant, oi);
            of.printOfferte(printToFile, filename);

        } else {
            Offerte of = new Offerte(klant, oi);
            of.printOfferte(false, "");
        }
    }

    public void toonKlanttyppes(){

        System.out.println("1. Particulier \n2. Bedrijf \n3. Overige klanttypes die u zelf in kunt stellen");
        System.out.println("");

    }
}