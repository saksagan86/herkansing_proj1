package main.test.io.github.ShipFlex.shipflex_application;

import main.java.io.github.ShipFlex.shipflex_application.Opties;
import main.java.io.github.ShipFlex.shipflex_application.OptiesInvoer;
import org.junit.Before;
import org.junit.Test;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.PrintStream;
import java.util.List;
import java.util.Scanner;

import static org.junit.Assert.*;

public class OptiesInvoerTest {

    private OptiesInvoer oi;

    @Before
    public void setUp() {
        oi = new OptiesInvoer();
    }

    @Test
    // Deze methode test de methode addEssentieleOpties() in de klasse OptiesInvoer.
    // Het maakt een nieuw Opties object aan, voegt er essentiële opties aan toe met behulp van de methode
    // addEssentieleOpties() en checked vervolgens dat het aantal essentiële opties in het object gelijk is aan 4.
    public void testAddEssentieleOpties() {
        Opties opties = new Opties("Boot", 0);
        oi.addEssentieleOpties(opties);
        assertEquals(4, opties.getEssentieleOpties().size());
    }

    @Test
    // Deze methode test de methode addExtraOpties() in de klasse OptiesInvoer.
    // Het maakt een nieuw Opties object aan, voegt er extra opties aan toe met behulp
    // van de methode addExtraOpties() en checked vervolgens dat het aantal extra opties in het object gelijk is aan 4.
    public void testAddExtraOpties() {
        Opties opties = new Opties("Boot", 0);
        oi.addExtraOpties(opties);
        assertEquals(4, opties.getExtraOpties().size());
    }

    @Test
    // Deze methode test de methode getGeselecteerdeOpties() in de klasse OptiesInvoer.
    // Het haalt de geselecteerde opties op met behulp van de methode getGeselecteerdeOpties()
    // en checked dat de lijst niet null en leeg is.
    public void testGetGeselecteerdeOpties() {
        List<Opties> geselecteerdeOpties = oi.getGeselecteerdeOpties();
        assertNotNull(geselecteerdeOpties);
        assertTrue(geselecteerdeOpties.isEmpty());
    }

    @Test
    // Methode om te verifiëren dat de methode geen exceptions geeft.
    // Deze methode test de methode displayEssentieleOpties() in de klasse OptiesInvoer.
    // Het maakt een nieuw object Opties en roept daarmee de methode displayEssentieleOpties() aan,
    // waarbij wordt gecontroleerd of er geen uitzonderingen worden gegeven.
    public void testDisplayEssentieleOpties() {
        Opties opties = new Opties("Test", 0);
        oi.displayEssentieleOpties(opties);
    }
    @Test
    // Methode om te verifiëren dat de methode geen exceptions geeft.
    public void testDisplayExtraOpties() {
        Opties opties = new Opties("Test", 0);
        oi.displayExtraOpties(opties);
    }

    @Test
    public void testResetOptieTeller() {
        String optieNaam = "TestExtraOptie";
        Opties opties = new Opties("TestOptie", 100);

        OptiesInvoer optiesInvoer = new OptiesInvoer();
        opties.addExtraOpties("TestCategory", "TestExtraOptie", 50);

        optiesInvoer.updateOptieTeller(optieNaam, opties);
        optiesInvoer.resetOptieTeller();
        assertTrue(optiesInvoer.getOptieTeller().isEmpty());
    }
    @Test
    public void testBerekenKorting() {
        Opties optie = new Opties("TestOptie", 100);
        String kortingInvoer = "25";
        OptiesInvoer optiesInvoer = new OptiesInvoer();
        boolean validKorting = optiesInvoer.berekenKorting(optie, false, kortingInvoer);

        assertTrue(validKorting);
        assertEquals(75, optie.getPrijs().intValue());
    }
    @Test
    public void testVoegKortingToe() {
        OptiesInvoer oi = new OptiesInvoer();
        Opties optie = new Opties("option",50);

        String input = "Ja\n20\n";
        ByteArrayInputStream inputStream = new ByteArrayInputStream(input.getBytes());
        System.setIn(inputStream);
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outputStream));
        Integer prijs = 40;
        oi.VoegKortingToe(optie);
        assertEquals(prijs,optie.getPrijs());
    }


}
