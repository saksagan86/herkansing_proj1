package main.test.io.github.ShipFlex.shipflex_application;

import static org.junit.Assert.*;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.List;
import java.util.Scanner;

import main.java.io.github.ShipFlex.shipflex_application.OptiesInvoer;
import org.junit.Before;
import org.junit.Test;

import main.java.io.github.ShipFlex.shipflex_application.Gebruiker;
import main.java.io.github.ShipFlex.shipflex_application.GebruikerLijst;
import main.java.io.github.ShipFlex.shipflex_application.BeginMenu;



public class GebruikerTest {
    private GebruikerLijst gebruikerLijst;

    @Before
    public void setUp() {
        gebruikerLijst = new GebruikerLijst();
    }


    @Test
    public void testGetGebruikers() {
        Gebruiker gebruiker1 = new Gebruiker("user1", "password1");
        Gebruiker gebruiker2 = new Gebruiker("user2", "password2");
        gebruikerLijst.voegGebruikerToe(gebruiker1);
        gebruikerLijst.voegGebruikerToe(gebruiker2);
        List<Gebruiker> gebruikers = gebruikerLijst.getGebruikers();
        assertEquals(2, gebruikers.size());
        assertEquals("user1", gebruikers.get(0).getGebruikersnaam());
        assertEquals("password1", gebruikers.get(0).getWachtwoord());
        assertEquals("user2", gebruikers.get(1).getGebruikersnaam());
        assertEquals("password2", gebruikers.get(1).getWachtwoord());
    }



    //nog een test maar hij gaf telkens errormelding
    //en ik heb geen idee waarom hij foutmelding geeft ->
    //------>
    //---->
    /*
    @Test
    public void testCheckLogin() {
        BeginMenu menu = new BeginMenu();
        GebruikerLijst gebruikerLijst = new GebruikerLijst();
        gebruikerLijst.voegGebruikerToe(new Gebruiker("Alice", "test123"));
        gebruikerLijst.voegGebruikerToe(new Gebruiker("Bob", "secret"));

        assertTrue(menu.checkLogin("Alice", "test123"));
        assertTrue(menu.checkLogin("Bob", "secret"));
        assertFalse(menu.checkLogin("Charlie", "password"));
        assertFalse(menu.checkLogin("Alice", "password"));
    }
     */


}
